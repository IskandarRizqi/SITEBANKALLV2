  <!-- start: Offcanvas Menu -->
  <div class="tj-offcanvas-area d-none d-lg-block">
      <div class="hamburger_bg"></div>
      <div class="hamburger_wrapper">
          <div class="hamburger_inner">
              <div class="hamburger_top d-flex align-items-center justify-content-between">
                  <div class="hamburger_logo">
                      <a href="index.html" class="mobile_logo">
                          <img src="frontend/bprman/assets/images/logos/logoman.png" alt="Logo">
                      </a>
                  </div>
                  <div class="hamburger_close">
                      <button class="hamburger_close_btn"><i class="fa-thin fa-times"></i></button>
                  </div>
              </div>
              <div class="offcanvas-text">
                  <p>Developing personalize our customer journeys to increase satisfaction & loyalty of our expansion
                      recognized
                      by industry leaders.</p>
              </div>
              <div class="hamburger-search-area">
                  <h5 class="hamburger-title">Search Now!</h5>
                  <div class="hamburger_search">
                      <form method="get" action="https://themejunction.net/html/bexon/demo/index.html">
                          <button type="submit"><i class="tji-search"></i></button>
                          <input type="search" autocomplete="off" name="s" value=""
                              placeholder="Search here...">
                      </form>
                  </div>
              </div>
              <div class="hamburger-infos">
                  <h5 class="hamburger-title">Contact Info</h5>
                  <div class="contact-info">
                      <div class="contact-item">
                          <span class="subtitle">Phone</span>
                          <a class="contact-link" href="tel:10095447818">+1 (009) 544-7818</a>
                      </div>
                      <div class="contact-item">
                          <span class="subtitle">Email</span>
                          <a class="contact-link" href="mailto:info@bexon.com">info@bexon.com</a>
                      </div>
                      <div class="contact-item">
                          <span class="subtitle">Location</span>
                          <span class="contact-link">993 Renner Burg, West Rond, MT 94251-030</span>
                      </div>
                  </div>
              </div>
          </div>
          <div class="hamburger-socials">
              <h5 class="hamburger-title">Follow Us</h5>
              <div class="social-links style-3">
                  <ul>
                      <li><a href="https://www.facebook.com/" target="_blank"><i
                                  class="fa-brands fa-facebook-f"></i></a>
                      </li>
                      <li><a href="https://www.instagram.com/" target="_blank"><i
                                  class="fa-brands fa-instagram"></i></a>
                      </li>
                      <li><a href="https://x.com/" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                      <li><a href="https://www.linkedin.com/" target="_blank"><i
                                  class="fa-brands fa-linkedin-in"></i></a>
                      </li>
                  </ul>
              </div>
          </div>
      </div>
  </div>
  <!-- end: Offcanvas Menu -->

  <!-- start: Hamburger Menu -->
  <div class="hamburger-area d-lg-none">
      <div class="hamburger_bg"></div>
      <div class="hamburger_wrapper">
          <div class="hamburger_inner">
              <div class="hamburger_top d-flex align-items-center justify-content-between">
                  <div class="hamburger_logo">
                      <a href="index.html" class="mobile_logo">
                          <img src="frontend/bprman/assets/images/logos/logoman.png" alt="Logo">
                      </a>
                  </div>
                  <div class="hamburger_close">
                      <button class="hamburger_close_btn"><i class="fa-thin fa-times"></i></button>
                  </div>
              </div>
              <div class="hamburger_menu">
                  <div class="mobile_menu"></div>
              </div>
              <div class="hamburger-infos">
                  <h5 class="hamburger-title">Contact Info</h5>
                  <div class="contact-info">
                      <div class="contact-item">
                          <span class="subtitle">Phone</span>
                          <a class="contact-link" href="tel:8089091313">808-909-1313</a>
                      </div>
                      <div class="contact-item">
                          <span class="subtitle">Email</span>
                          <a class="contact-link" href="mailto:info@bexon.com">info@bexon.com</a>
                      </div>
                      <div class="contact-item">
                          <span class="subtitle">Location</span>
                          <span class="contact-link">993 Renner Burg, West Rond, MT 94251-030</span>
                      </div>
                  </div>
              </div>
          </div>
          <div class="hamburger-socials">
              <h5 class="hamburger-title">Follow Us</h5>
              <div class="social-links style-3">
                  <ul>
                      <li><a href="https://www.facebook.com/" target="_blank"><i
                                  class="fa-brands fa-facebook-f"></i></a>
                      </li>
                      <li><a href="https://www.instagram.com/" target="_blank"><i
                                  class="fa-brands fa-instagram"></i></a>
                      </li>
                      <li><a href="https://x.com/" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                      <li><a href="https://www.linkedin.com/" target="_blank"><i
                                  class="fa-brands fa-linkedin-in"></i></a>
                      </li>
                  </ul>
              </div>
          </div>
      </div>
  </div>
  <!-- end: Hamburger Menu -->

  <!-- start: Header Area -->
  <header class="header-area header-1 header-absolute  section-gap-x">
      <div class="container-fluid">
          <div class="row">
              <div class="col-12">
                  <div class="header-wrapper">
                      <!-- site logo -->
                      <div class="site_logo">
                          <a class="logo" href="index.html"><img src="frontend/bprman/assets/images/logos/logoman.png"
                                  alt=""></a>
                      </div>

                      <!-- navigation -->
                      <div class="menu-area d-none d-lg-inline-flex align-items-center">
                          <nav id="mobile-menu" class="mainmenu">
                             <ul>
                                  <li><a href="/">Beranda</a>

                                  </li>

                                  <li class="has-dropdown"><a href="#">Tentang Kami</a>
                                      <ul class="sub-menu">
                                          <li><a href="/profile">Profil</a></li>
                                          <li><a href="/sejarah">Sejarah</a></li>
                                          <li><a href="/pengurus">Pengurus</a></li>
                                          <li><a href="/organisasi">Struktur Organisasi</a></li>
                                          <li><a href="/galery">Gallery</a></li>
                                      </ul>
                                  </li>
                                  <li class="has-dropdown"><a href="#">Produk</a>
                                      <ul class="sub-menu">
                                          <li><a href="/kredit">Kredit</a></li>
                                          <li><a href="/deposito">Deposito</a></li>
                                          <li><a href="/tabungan">Tabungan</a></li>

                                      </ul>
                                  </li>
                                  <li class="has-dropdown"><a href="#">Laporan</a>
                                      <ul class="sub-menu">
                                          <li><a href="/publikasi">Publikasi</a></li>
                                          <li><a href="/tahunan">Tahunan</a></li>
                                          <li><a href="/tata">Tata Kelola</a></li>
                                          <li><a href="blog-right-sidebar.html">Keberlanjutan</a></li>
                                          <li><a href="blog-right-sidebar.html">Audit Charter</a></li>

                                      </ul>
                                  </li>
                                  <li><a href="/lelang-jualaset">Lelang</a></li>
                                  <li><a href="/pengajuanonline">Pengajuan Online</a></li>
                                  <li class="has-dropdown"><a href="#">Simulasi</a>
                                    <ul class="sub-menu">
                                        <li><a href="/kredit">Kredit</a></li>
                                        <li><a href="/deposito">Deposito</a></li>
                                        <li><a href="/tabungan">Tabungan</a></li>
                                    </ul>
                                  </li>
                                  <li class="has-dropdown"><a href="#">Kontak</a>
                                    <ul class="sub-menu">
                                        <li><a href="#">Pengaduan Nasabah</a></li>
                                        <li><a href="#">Laporan Pelanggaran</a></li>
                                    </ul>
                                  </li>
                              </ul>
                          </nav>
                      </div>

                      <!-- header right info -->
                      <div class="header-right-item d-none d-lg-inline-flex">
                          
                          <!-- <div class="header-button">
                              <a class="tj-primary-btn" href="contact.html">
                                  <span class="btn-text"><span>Simulasi</span></span>
                                  <span class="btn-icon"><i class="tji-arrow-right-long"></i></span>
                              </a>
                          </div> -->
                          <div class="menu_bar menu_offcanvas d-none d-lg-inline-flex">
                              <span></span>
                              <span></span>
                              <span></span>
                          </div>
                      </div>

                      <!-- menu bar -->
                      <div class="menu_bar mobile_menu_bar d-lg-none">
                          <span></span>
                          <span></span>
                          <span></span>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <!-- Search Popup -->
      <div class="search_popup">
          <div class="container">
              <div class="row justify-content-center">
                  <div class="col-8">
                      <div class="tj_search_wrapper">
                          <div class="search_form">
                              <form action="#">
                                  <div class="search_input">
                                      <div class="search-box">
                                          <input class="search-form-input" type="text"
                                              placeholder="Type Words and Hit Enter" required>
                                          <button type="submit">
                                              <i class="tji-search"></i>
                                          </button>
                                      </div>
                                  </div>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </header>
  <!-- end: Header Area -->



  <!-- start: Header Area -->
  <header class="header-area header-1 header-duplicate header-sticky section-gap-x">
      <div class="container-fluid">
          <div class="row">
              <div class="col-12">
                  <div class="header-wrapper">
                      <!-- site logo -->
                      <div class="site_logo">
                          <a class="logo" href="index.html"><img src="frontend/bprman/assets/images/logos/logoman.png"
                                  alt=""></a>
                      </div>

                      <!-- navigation -->
                      <div class="menu-area d-none d-lg-inline-flex align-items-center">
                          <nav class="mainmenu">
                              <ul>
                                  <li><a href="/">Beranda</a>

                                  </li>

                                  <li class="has-dropdown"><a href="#">Tentang Kami</a>
                                      <ul class="sub-menu">
                                          <li><a href="/profile">Profil</a></li>
                                          <li><a href="/sejarah">Sejarah</a></li>
                                          <li><a href="/pengurus">Pengurus</a></li>
                                          <li><a href="/organisasi">Struktur Organisasi</a></li>
                                          <li><a href="/galery">Gallery</a></li>
                                      </ul>
                                  </li>
                                  <li class="has-dropdown"><a href="#">Produk</a>
                                      <ul class="sub-menu">
                                          <li><a href="/kredit">Kredit</a></li>
                                          <li><a href="/deposito">Deposito</a></li>
                                          <li><a href="/tabungan">Tabungan</a></li>

                                      </ul>
                                  </li>
                                  <li class="has-dropdown"><a href="#">Laporan</a>
                                    <ul class="sub-menu">
                                        <li><a href="/publikasi">Publikasi</a></li>
                                        <li><a href="/tahunan">Tahunan</a></li>
                                        <li><a href="/tata">Tata Kelola</a></li>
                                        <li><a href="blog-right-sidebar.html">Keberlanjutan</a></li>
                                        <li><a href="blog-right-sidebar.html">Audit Charter</a></li>
                                    </ul>
                                  </li>
                                  <li><a href="/lelang-jualaset">Lelang</a></li>
                                  <li><a href="/pengajuanonline">Pengajuan Online</a></li>
                                  <li class="has-dropdown"><a href="#">Simulasi</a>
                                    <ul class="sub-menu">
                                        <li><a href="/kredit">Kredit</a></li>
                                        <li><a href="/deposito">Deposito</a></li>
                                        <li><a href="/tabungan">Tabungan</a></li>
                                    </ul>
                                  </li>
                                  <li class="has-dropdown"><a href="#">Kontak</a>
                                    <ul class="sub-menu">
                                        <li><a href="#">Pengaduan Nasabah</a></li>
                                        <li><a href="#">Laporan Pelanggaran</a></li>
                                    </ul>
                                  </li>
                              </ul>
                          </nav>
                      </div>

                      <!-- header right info -->
                      <div class="header-right-item d-none d-lg-inline-flex">
                          <!-- <div class="header-search">
                              <button class="search">
                                  <i class="tji-search"></i>
                              </button>
                              <button type="button" class="search_close_btn">
                                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                      xmlns="http://www.w3.org/2000/svg">
                                      <path d="M17 1L1 17" stroke="currentColor" stroke-width="1.5"
                                          stroke-linecap="round" stroke-linejoin="round" />
                                      <path d="M1 1L17 17" stroke="currentColor" stroke-width="1.5"
                                          stroke-linecap="round" stroke-linejoin="round" />
                                  </svg>
                              </button>
                          </div>
                          <div class="header-button">
                              <a class="tj-primary-btn" href="contact.html">
                                  <span class="btn-text"><span>Simulasi</span></span>
                                  <span class="btn-icon"><i class="tji-arrow-right-long"></i></span>
                              </a>
                          </div> -->
                          <div class="menu_bar menu_offcanvas d-none d-lg-inline-flex">
                              <span></span>
                              <span></span>
                              <span></span>
                          </div>
                      </div>

                      <!-- menu bar -->
                      <div class="menu_bar mobile_menu_bar d-lg-none">
                          <span></span>
                          <span></span>
                          <span></span>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <!-- Search Popup -->
      <div class="search_popup">
          <div class="container">
              <div class="row justify-content-center">
                  <div class="col-8">
                      <div class="tj_search_wrapper">
                          <div class="search_form">
                              <form action="#">
                                  <div class="search_input">
                                      <div class="search-box">
                                          <input class="search-form-input" type="text"
                                              placeholder="Type Words and Hit Enter" required>
                                          <button type="submit">
                                              <i class="tji-search"></i>
                                          </button>
                                      </div>
                                  </div>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </header>
  <!-- end: Header Area -->
